<?php
	include 'header.php';
	include 'navbar.php';
?>
<?php 
include '../koneksi.php';
$UlasanID = $_GET['UlasanID'];
$data = mysqli_query($koneksi,"SELECT * FROM  ulasanbuku INNER JOIN user ON ulasanbuku.UserID=user.UserID INNER JOIN buku ON ulasanbuku.BukuID=buku.BukuID WHERE ulasanbuku.UlasanID=" . $_GET['UlasanID']);
while($d_koleksi = mysqli_fetch_array($data)){ 
    ?> 
<div class="content mt-3">
	<div class="card">
		<div class="card-body">
            <form method="post" action="proses_update_ulasan.php">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" class="form-control" name="Username" disabled value="<?=$_SESSION['Username']?>">
                    <input type="hidden" class="form-control" name="UserID" value="<?=$_SESSION['UserID']?>">
                    <input type="hidden" class="form-control" name="UlasanID" value="<?=$UlasanID?>">
                </div>
                <div class="form-group">
                    <label>Pilih Buku</label>
                    <input type="hidden" name="KategoriID" value="<?php echo $d_koleksi['KategoriID']; ?>">
                    <select class="form-control mt-2" name="BukuID">
                        <option>Silahkan Pilih</option>
                    <?php 
		            include '../koneksi.php';
		            $data = mysqli_query($koneksi,"select * from buku");
		            while($d_buku = mysqli_fetch_array($data)){?>
                        <option value="<?php echo $d_buku['BukuID']; ?>" <?php if ($d_buku['BukuID'] == $d_koleksi['BukuID']) {echo "selected";} ?>><?php echo $d_buku['Judul']; ?></option>
                    <?php } ?> 
                    </select>
                </div>
                <div class="form-group">
                    <label>Ulasan</label>
                    <input type="text" class="form-control" value="<?php echo $d_koleksi['Ulasan']; ?>" name="Ulasan">
                </div>
                <div class="form-group">
                    <label for="rating">Rating</label>
                    <?php $Rating = $d_koleksi['Rating']; ?>
                    <select name="Rating" class="form-control">
                        <option <?= ($Rating == '1') ? "selected": ""?> >1</option>
                        <option <?= ($Rating == '2') ? "selected": ""?> >2</option>
                        <option <?= ($Rating == '3') ? "selected": ""?> >3</option>
                        <option <?= ($Rating == '4') ? "selected": ""?> >4</option>
                        <option <?= ($Rating == '5') ? "selected": ""?> >5</option>
                        <option <?= ($Rating == '6') ? "selected": ""?> >6</option>
                        <option <?= ($Rating == '7') ? "selected": ""?> >7</option>
                        <option <?= ($Rating == '8') ? "selected": ""?> >8</option>
                        <option <?= ($Rating == '9') ? "selected": ""?> >9</option>
                        <option <?= ($Rating == '10') ? "selected": ""?> >10</option>
                    </select>
                </div>
                <div class="form-group">
                    <button type="submit" class="form-control btn btn-primary btn-sm mt-3">Simpan</button>
                </div>
            </form>
		</div>
	</div>
</div>
<?php } ?>

<?php
	include 'footer.php';
?>